﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Josiah Bandstra
 * Rock Paper Scissors Game VS Computer
 * Prof. Fleenor CIS-218
 * Thursday, September 24, 2020*/
namespace RockPaperScissors
{

    public partial class Form1 : Form
    { 
        int CPUChoice;
        int PlayerChoice;

        string output;

        //Buttons and what the player clicks
        public Form1()
        {
            InitializeComponent();

        }

            private void button2_Click(object sender, EventArgs e)
        {
            PlayerChoice = 1;
            checkGame();
        }

        private void btnRock_Click(object sender, EventArgs e)
        {
            PlayerChoice = 0;
            checkGame();
        }

        private void btnScissors_Click(object sender, EventArgs e)
        {
            PlayerChoice = 2;
            checkGame();
        }
        // Outcomes for when the player picks an object, who will win.
        //Random Number Generator
        private void checkGame()
        {
            Random ranNumberGenerator = new Random();

            CPUChoice = ranNumberGenerator.Next(0, 2);

            // rock = 0, paper = 1, scissors = 2
            if (PlayerChoice == 0 && CPUChoice == 1)
            {
                output =("CPU Wins, Paper Covers Rock");
                label1.Text = output;
            }
            else if (PlayerChoice == 2 && CPUChoice == 0)
            {
                output = ("CPU Wins, Rock Breaks Scissors");
                label1.Text = output;
            }
            else if (PlayerChoice == 1 && CPUChoice == 2)
            {
                output = ("CPU Wins, Scissors cuts Paper");
                label1.Text = output;
            }
            else if (PlayerChoice == 0 && CPUChoice == 2)
            {
                output = ("Player Wins, Rock breaks Scissors");
                label1.Text = output;
            }
            else if (PlayerChoice == 1 && CPUChoice == 0)
            {
                output = ("Player Wins, Paper covers Rock");
                label1.Text = output;
            }
            else if (PlayerChoice == 2 && CPUChoice == 1)
            {
                output = ("Player Wins, Scissors cuts Paper");
                label1.Text = output;
            }
            else
            {
                output = ("Draw!");
                label1.Text = output;
            }
        }

        private void outputbox_Click(object sender, EventArgs e)
        {

        }
    }
}
